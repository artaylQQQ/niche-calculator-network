module.exports = {
  content: ["./src/**/*.{astro,html,js,jsx,md,mdx,ts,tsx}"],
  theme: { extend: { container: { center: true, padding: "1rem" } } },
  plugins: []
};
